# 🧠 Day 11 — React & TypeScript 실전 루틴

> 날짜: **2025.10.26**  
> 루틴: React + TypeScript 84일 학습  
> 노션: https://www.notion.so/React-TypeScript-Day-1-14-28d811fbadda81b28ae0cdc4dcdd33d0

---

# 🧠 Day 11 — 학습 주제
> **학습 기간:** 2025.10.26  
> **총 루틴:** React + TypeScript 실전 루틴 (Day 11/84)  
> **소요 시간:** ⏰ 30분 ~ 1시간  

---

## 🎯 오늘의 목표
- 핵심 개념 복습/실습
- 작은 예제 한 개 완성

## 🎥 참고 자료
- 📘 MDN – JavaScript 개요: https://developer.mozilla.org/ko/docs/Web/JavaScript
- 🔗 노션 섹션: https://www.notion.so/React-TypeScript-Day-1-14-28d811fbadda81b28ae0cdc4dcdd33d0

## 💻 실습 코드 (예시)
```ts
function greet(name: string) {
  return `안녕하세요, ${name}!`;
}
console.log(greet("해림"));
```

## ✅ 체크리스트
- [ ] 개념 설명 가능
- [ ] 예제 코드 작성
- [ ] 회고 작성

## 📝 오늘의 회고
✅ 배운 점: …  
❓ 헷갈린 점: …  
💡 개선 포인트: …  

📌 내일 목표: Day 12 예고
